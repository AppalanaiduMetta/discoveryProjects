package com.amiIt.amidashboard;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmidashboardApplicationTests {

//	@Test
	void contextLoads() {
	}

}
