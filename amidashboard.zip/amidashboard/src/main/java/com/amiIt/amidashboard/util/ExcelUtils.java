package com.amiIt.amidashboard.util;

import org.springframework.web.multipart.MultipartFile;

public class ExcelUtils {
	public static String EXCELTYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static boolean isExcelFile(MultipartFile file) {
		
		if(!EXCELTYPE.equals(file.getContentType())) {
			return false;
		}
		
		return true;
	}
}
