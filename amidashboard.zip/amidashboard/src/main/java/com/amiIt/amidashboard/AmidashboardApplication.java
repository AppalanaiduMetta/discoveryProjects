package com.amiIt.amidashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmidashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmidashboardApplication.class, args);
	}

}
